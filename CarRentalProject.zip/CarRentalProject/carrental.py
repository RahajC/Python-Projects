class Car:
    def __init__(self, make, model, year, color):
        self.make = make
        self.model = model
        self.year = year
        self.color = color

    def toyota(self):
        print(self.make + " " + self.model + " " + self.year + " " + self.color)
        print("Description: Fuel efficient and affordable car\n")

    def honda(self):
        print(self.make + " " + self.model + " " + self.year + " " + self.color)
        print("Description: Smooth and fuel efficient car\n")

    def nissan(self):
        print(self.make + " " + self.model + " " + self.year + " " + self.color)
        print("Description: Large SUV for family use\n")
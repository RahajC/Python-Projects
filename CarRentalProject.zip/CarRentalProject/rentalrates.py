class RentalRate:
    def __init__(self,rate,hour,day,week):
        self.rate = rate
        self.hour = hour
        self.day = day
        self.week = week

    def hourly(self):
        x = self.rate * self.hour
        return x

    def daily(self):
        x = self.rate * self.day
        return x

    def weekly(self):
        x = self.rate * self.week
        return x

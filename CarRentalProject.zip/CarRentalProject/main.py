from carrental import Car
from rentalrates import RentalRate

toyota_1 = Car("Toyota", "Prius", "2018", "Red")
honda_1 = Car("Honda", "Civic", "2018", "Black")
nissa_1 = Car("Nissan", "Pathfinder", "2018", "White")

a = input("Would you like to view the available cars for rent?\n")
if(a=="yes"):
    print("Available Cars for Rent:")
    print("A: Toyota Prius")
    print("B: Honda Civic")
    print("C: Nissan Pathfinder")
else:
    print("End car rental program")

b = input("What car would you like to choose?\n")
A = "A"
B = "B"
C = "C"
#toyota_1.toyota()
if(b == A):
    toyota_1.toyota()
elif (b == B):
    honda_1.honda()
elif (b == C):
    nissa_1.nissan()
else:
    print("Have a good day !")

print("Rental Rate Options: ")
print("1: Hours, Hourly Rate: $20/hour")
print("2: Days, Daily Rate: $50/day")
print("3: Weeks, Weekly Rate: $100/week")

c = input("What rental option would you like to choose?\n")


hourly_rate = 20
daily_rate = 50
weekly_rate = 100
one = "1"
two = "2"
three = "3"


if(c==one):
    d = int(input("How many hours do you intend to rent the car?\n"))
    hourly1 = RentalRate(hourly_rate, d,0,0)
    print("Your total is: ")
    print("$" + str(hourly1.hourly()))
elif(c==two):
    d = int(input("How many days do you intend to rent the car?\n"))
    daily1 = RentalRate(daily_rate,0, d,0)
    print("Your total is: ")
    print("$" + str(daily1.daily()))
elif(c==three):
    d = int(input("How many weeks do you intend to rent the car?\n"))
    weekly1 = RentalRate(weekly_rate,0,0, d)
    print("Your total is: ")
    print("$" + str(weekly1.weekly()))
else:
    print("Have a good day !")



import random

value = random.randint(0,20)
print(value)
b = 0
while b<100:
    a = int(input("Enter a value\n"))
    if (a == value):
        print("Correct Value")
        break
    else:
        print("Try Again !")
        b = b + 1




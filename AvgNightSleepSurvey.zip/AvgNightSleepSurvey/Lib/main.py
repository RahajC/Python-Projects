
print("Average Night Survery")

carryOn = "Yes"
totalHours = 0
numberOfStudents = 0

while carryOn == "Yes":
    hours = int(input("How many hours do you sleep each night?\n"))
    totalHours = totalHours + hours
    numberOfStudents = numberOfStudents + 1
    average = totalHours/numberOfStudents
    print("Average number of hours per night: " + str(average))
    carryOn = input("Do you want to carry on with the survey? Yes/No\n")

print("Total number of students in the survey: " + str(numberOfStudents))


